
int bitOr(int, int);
int test_bitOr(int, int);
int logicalShift(int, int);
int test_logicalShift(int, int);
int bitCount(int);
int test_bitCount(int);
int negate(int);
int test_negate(int);
int addOK(int);
int test_addOK(int);
int isLessOrEqual(int, int);
int test_isLessOrEqual(int, int);
unsigned float_neg(unsigned);
unsigned test_float_neg(unsigned);
unsigned float_i2f(int);
unsigned test_float_i2f(int);
unsigned float_twice(unsigned);
unsigned test_float_twice(unsigned);
